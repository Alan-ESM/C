﻿using System;

class ProgrammeHornerManga
{
    // ===== Méthode qui écrit un texte en couleur =====
    static void EcrireCouleur(string texte, ConsoleColor couleur)
    {
        Console.ForegroundColor = couleur;
        Console.WriteLine(texte);
        Console.ResetColor();
    }

    // ===== Lecture sécurisée : n'accepte que des nombres =====
    static double LireNombre(string message)
    {
        double valeur;
        Console.Write(message);

        // Tant qu'on n'a pas une valeur numérique
        while (!double.TryParse(Console.ReadLine(), out valeur))
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("⚠ ERREUR : entre un nombre valide !");
            Console.ResetColor();
            Console.Write(message);
        }

        return valeur;
    }

    // ===== Méthode de Horner =====
    static double Horner(double[] coefficients, double x)
    {
        double resultat = coefficients[0];

        for (int i = 1; i < coefficients.Length; i++)
        {
            resultat = resultat * x + coefficients[i];
        }

        return resultat;
    }

    // ===== Programme principal =====
    static void Main()
    {
        // Titre décoré
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("===============================================");
        Console.WriteLine(" 💙  BIENVENUE DANS LE PROGRAMME HORNER MANGA ! 💙");
        Console.WriteLine("===============================================");
        Console.ResetColor();
        Console.WriteLine();

        // Lecture du degré du polynôme
        int degre;
        do
        {
            Console.Write("Entre le degré du polynôme (ex: 2 pour ax² + bx + c) : ");
        }
        while (!int.TryParse(Console.ReadLine(), out degre) || degre < 0);

        Console.WriteLine();

        // Tableau des coefficients : nom manga → "coefGoku", "coefNaruto", etc.
        double[] coefManga = new double[degre + 1];

        // Remplissage du tableau
        for (int i = 0; i <= degre; i++)
        {
            coefManga[i] = LireNombre($"Coefficient a{i} (du terme x^{degre - i}) : ");
        }

        Console.WriteLine();

        // Lecture de la valeur x
        double valeurX = LireNombre("Entre la valeur de x : ");
        Console.WriteLine();

        // Calcul avec Horner
        double resultatFinal = Horner(coefManga, valeurX);

        // Affichage en vert
        EcrireCouleur($"⭐ Résultat : P({valeurX}) = {resultatFinal}", ConsoleColor.Green);

        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine(" Merci d’avoir utilisé le programme Horner Manga ! ");
        Console.ResetColor();
    }
}