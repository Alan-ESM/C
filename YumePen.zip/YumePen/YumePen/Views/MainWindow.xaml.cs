﻿using MahApps.Metro.Controls;
using Microsoft.Win32; // ← Pour OpenFileDialog / SaveFileDialog WPF
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Forms; // ← UNIQUEMENT pour ColorDialog
// Ajout indispensable pour éviter les ambiguïtés
using DataFormats = System.Windows.DataFormats; // ← WPF
using WpfOpenFileDialog = Microsoft.Win32.OpenFileDialog;
using WpfSaveFileDialog = Microsoft.Win32.SaveFileDialog;
namespace YumePen.Views
{
    public partial class MainWindow : MetroWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += (s, e) => Editor.Focus();
        }
        // ────────────────────── FICHIER ──────────────────────
        private void BtnNew_Click(object sender, RoutedEventArgs e)
        {
            Editor.Document.Blocks.Clear();
            Editor.Focus();
        }
        private void BtnOpen_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new WpfOpenFileDialog
            {
                Filter = "Rich Text Format (*.rtf)|*.rtf|Texte (*.txt)|*.txt|Tous les fichiers (*.*)|*.*"
            };
            if (dlg.ShowDialog() == true)
            {
                var range = new TextRange(Editor.Document.ContentStart, Editor.Document.ContentEnd);
                using (var fs = File.OpenRead(dlg.FileName)) // ← plus simple et sûr
                {
                    if (Path.GetExtension(dlg.FileName).ToLowerInvariant() == ".rtf")
                        range.Load(fs, DataFormats.Rtf);
                    else
                        range.Load(fs, DataFormats.Text);
                }
            }
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new WpfSaveFileDialog
            {
                Filter = "Rich Text Format (*.rtf)|*.rtf|Texte (*.txt)|*.txt",
                DefaultExt = "rtf",
                FileName = "Mon journal de rêves.rtf"
            };
            if (dlg.ShowDialog() == true)
            {
                var range = new TextRange(Editor.Document.ContentStart, Editor.Document.ContentEnd);
                using (var fs = File.Create(dlg.FileName))
                {
                    if (Path.GetExtension(dlg.FileName).ToLowerInvariant() == ".rtf")
                        range.Save(fs, DataFormats.Rtf);
                    else
                        range.Save(fs, DataFormats.Text);
                }
            }
        }
        // ────────────────────── ALIGNEMENT ──────────────────────
        private void BtnAlignLeft_Click(object sender, RoutedEventArgs e) => EditingCommands.AlignLeft.Execute(null, Editor);
        private void BtnAlignCenter_Click(object sender, RoutedEventArgs e) => EditingCommands.AlignCenter.Execute(null, Editor);
        private void BtnAlignRight_Click(object sender, RoutedEventArgs e) => EditingCommands.AlignRight.Execute(null, Editor);
        // ────────────────────── FORMAT TEXTE ──────────────────────
        private void BtnBold_Click(object sender, RoutedEventArgs e) => EditingCommands.ToggleBold.Execute(null, Editor);
        private void BtnItalic_Click(object sender, RoutedEventArgs e) => EditingCommands.ToggleItalic.Execute(null, Editor);
        private void BtnUnderline_Click(object sender, RoutedEventArgs e) => EditingCommands.ToggleUnderline.Execute(null, Editor);
        // ────────────────────── IMAGE ──────────────────────
        private void BtnInsertImage_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new WpfOpenFileDialog
            {
                Filter = "Images|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.webp"
            };
            if (dlg.ShowDialog() == true)
            {
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new System.Uri(dlg.FileName);
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                var img = new Image
                {
                    Source = bitmap,
                    Width = 450,
                    Stretch = Stretch.Uniform,
                    Margin = new Thickness(0, 10, 0, 10)
                };
                var container = new InlineUIContainer(img, Editor.CaretPosition);
                Editor.CaretPosition = container.ElementEnd;
                Editor.Focus();
            }
        }
        // ────────────────────── POLICE & TAILLE ──────────────────────
        private void FontFamilyCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FontFamilyCombo.SelectedItem is ComboBoxItem item &&
                item.FontFamily != null &&
                Editor?.Selection != null &&
                !Editor.Selection.IsEmpty)
            {
                Editor.Selection.ApplyPropertyValue(TextElement.FontFamilyProperty, item.FontFamily);
                Editor.Focus();
            }
        }
        private void FontSizeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FontSizeCombo.SelectedItem is ComboBoxItem item &&
                double.TryParse(item.Content?.ToString(), out double size) && size > 0 &&
                Editor?.Selection != null &&
                !Editor.Selection.IsEmpty)
            {
                Editor.Selection.ApplyPropertyValue(TextElement.FontSizeProperty, size);
                Editor.Focus();
            }
        }
        // ────────────────────── COULEURS ──────────────────────
        private void TextColorBtn_Click(object sender, RoutedEventArgs e)
        {
            using (var dlg = new ColorDialog())
            {
                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK && Editor?.Selection != null)
                {
                    var color = Color.FromArgb(dlg.Color.A, dlg.Color.R, dlg.Color.G, dlg.Color.B);
                    Editor.Selection.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush(color));
                    Editor.Focus();
                }
            }
        }
        private void HighlightBtn_Click(object sender, RoutedEventArgs e)
        {
            using (var dlg = new ColorDialog())
            {
                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK && Editor?.Selection != null)
                {
                    var color = Color.FromArgb(dlg.Color.A, dlg.Color.R, dlg.Color.G, dlg.Color.B);
                    Editor.Selection.ApplyPropertyValue(TextElement.BackgroundProperty, new SolidColorBrush(color));
                    Editor.Focus();
                }
            }
        }
    }
}
