﻿using System;

class ProgrammeHornerSaintSeiya
{
    // ===== Méthode couleur =====
    static void Couleur(string texte, ConsoleColor couleur)
    {
        Console.ForegroundColor = couleur;
        Console.WriteLine(texte);
        Console.ResetColor();
    }

    // ===== Lecture sécurisée avec message Athéna + emojis =====
    static double LireNombre(string message)
    {
        double valeur;
        int erreurs = 0;

        Console.Write(message);
        string saisie = Console.ReadLine();

        while (!double.TryParse(saisie, out valeur))
        {
            erreurs++;

            Console.ForegroundColor = ConsoleColor.Red;

            if (erreurs == 1)
            {
                Console.WriteLine("⚠️ Erreur : tu dois entrer un nombre valide !");
            }
            else
            {
                Console.WriteLine("⚠️⚔️ « La même erreur ne devrait pas fonctionner 2 fois sur un Chevalier d’Athéna ! » ⚔️⚠️");
            }

            Console.ResetColor();

            Console.Write(message);
            saisie = Console.ReadLine();
        }

        return valeur;
    }

    // ===== Méthode Horner =====
    static double Horner(double[] coef, double x)
    {
        double resultat = coef[0];

        for (int i = 1; i < coef.Length; i++)
        {
            resultat = resultat * x + coef[i];
        }

        return resultat;
    }

    // ===== Programme principal =====
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        // ——— Titre ———
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("===============================================================");
        Console.WriteLine(" 💙💫   BIENVENUE DANS LE PROGRAMME HORNER SAINT SEIYA   💫💙 ");
        Console.WriteLine("===============================================================");
        Console.ResetColor();
        Console.WriteLine();

        // ——— Lecture du degré ———
        int degre;
        int erreurDegre = 0;

        Console.Write("🎓 Entre le degré du polynôme (ex: 2 pour ax² + bx + c) : ");
        string saisieDegre = Console.ReadLine();

        while (!int.TryParse(saisieDegre, out degre) || degre < 0)
        {
            erreurDegre++;

            Console.ForegroundColor = ConsoleColor.Red;
            if (erreurDegre == 1)
                Console.WriteLine("❌ Erreur : tu dois entrer un entier chevalier !");
            else
                Console.WriteLine("🔥⚔️ Athéna : « Répéter une erreur ? Pas digne d'un Chevalier ! » ⚔️🔥");
            Console.ResetColor();

            Console.Write("🎓 Entre le degré du polynôme : ");
            saisieDegre = Console.ReadLine();
        }

        Console.WriteLine();

        // ——— Création du tableau de coefficients ———
        double[] coefCosmo = new double[degre + 1];

        for (int i = 0; i <= degre; i++)
        {
            int puissance = degre - i;
            coefCosmo[i] = LireNombre($"✨ Coefficient du terme x^{puissance} : ");
        }

        Console.WriteLine();

        // ——— Lecture de x ———
        double xValeur = LireNombre("⭐ Entre la valeur de x : ");
        Console.WriteLine();

        // ——— Calcul ———
        double resultat = Horner(coefCosmo, xValeur);

        // ——— Résultat en vert ———
        Couleur($"🌟 Résultat : P({xValeur}) = {resultat}", ConsoleColor.Green);

        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("🌸💙 Merci d’avoir utilisé le Programme Horner Saint Seiya ! 💙🌸");
        Console.WriteLine("🔥 Que ton Cosmos brûle toujours plus fort ! 🔥");
        Console.ResetColor();
    }
}
