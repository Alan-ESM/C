﻿using System;

namespace EquationTroisiemeDegre
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "EQUATIONS DU 3EME DEGRE ";
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== RESOLVEUR D'EQUATIONS DU 3EME DEGRE ===");
            Console.WriteLine("Forme: ax³ + bx² + cx + d = 0\n");
            Console.WriteLine("Fun fact: Les equations du 3eme degre ont terrorise les mathematiciens pendant des siecles!");
            Console.WriteLine("Heureusement, vous avez ce programme 😎\n");
            Console.ResetColor();

            while (true)
            {
                double a = LireCoefficient("a");

                if (a == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("ERREUR: Le coefficient 'a' ne peut pas etre zero!");
                    Console.WriteLine("Sinon ce n'est plus du 3eme degre... C'est comme commander une pizza sans pizza!");
                    Console.ResetColor();
                    return;
                }

                double b = LireCoefficient("b");
                double c = LireCoefficient("c");
                double d = LireCoefficient("d");

                Console.WriteLine($"\nEquation: {a}x³ + {b}x² + {c}x + {d} = 0");
                Console.WriteLine("\nChoisissez votre methode de resolution:");
                Console.WriteLine("1. Methode classique (rapide et efficace)");
                Console.WriteLine("2. Methode de Cardan (pour les puristes et les curieux)");
                Console.WriteLine("3. Quitter le programme");

                Console.Write("\nVotre choix (1, 2 ou 3): ");
                string choix = Console.ReadLine()?.Trim() ?? string.Empty;

                if (choix == "1")
                {
                    Console.WriteLine("\n🚀 Excellent choix! On y va a la vitesse de la lumiere!");
                    MethodeClassique(a, b, c, d);
                    break;
                }
                else if (choix == "2")
                {
                    Console.WriteLine("\n🎓 Ah, un amateur de formules complexes! Cardan serait fier de vous!");
                    MethodeCardan(a, b, c, d);
                    break;
                }
                else if (choix == "3")
                {
                    Console.WriteLine("\n👋 Merci d'avoir utilise le resolveur d'equations du 3eme degre! A bientot!");
                    return;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nERREUR: Choix invalide! Veuillez entrer 1, 2 ou 3.");
                    Console.ResetColor();
                }
            }

            Console.WriteLine("\n💡 Le saviez-vous? Cardan a publie sa methode en 1545, mais c'est Tartaglia qui l'a decouverte!");
            Console.WriteLine("Appuyez sur une touche pour quitter...");
            Console.ReadKey();
        }

        static void MethodeClassique(double a, double b, double c, double d)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n--- ETAPE 1: Normalisation ---");

            b = b / a;
            c = c / a;
            d = d / a;
            a = 1;

            Console.WriteLine($"Equation normalisee: x³ + {b}x² + {c}x + {d} = 0");

            Console.WriteLine("\n--- ETAPE 2: Changement de variable ---");

            double p = c - (b * b) / 3;
            double q = d - (b * c) / 3 + (2 * b * b * b) / 27;

            Console.WriteLine($"p = {p}");
            Console.WriteLine($"q = {q}");

            Console.WriteLine("\n--- ETAPE 3: Calcul du discriminant ---");

            double discriminant = -(4 * p * p * p + 27 * q * q);

            Console.WriteLine($"Discriminant = {discriminant}");

            Console.WriteLine("\n--- ETAPE 4: Resolution ---");

            if (discriminant > 0)
            {
                Console.WriteLine("Discriminant > 0: Jackpot! Trois racines reelles!");

                double m = 2 * Math.Sqrt(-p / 3);
                double theta = Math.Acos((3 * q) / (p * m)) / 3;

                double t1 = m * Math.Cos(theta);
                double t2 = m * Math.Cos(theta - 2 * Math.PI / 3);
                double t3 = m * Math.Cos(theta - 4 * Math.PI / 3);

                double x1 = t1 - b / 3;
                double x2 = t2 - b / 3;
                double x3 = t3 - b / 3;

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n🎉 === SOLUTIONS === 🎉");
                Console.WriteLine($"x1 = {x1}");
                Console.WriteLine($"x2 = {x2}");
                Console.WriteLine($"x3 = {x3}");
                Console.ResetColor();
            }
            else if (Math.Abs(discriminant) < 1e-10)
            {
                Console.WriteLine("Discriminant = 0: Des racines multiples!");

                double t1 = 3 * q / p;
                double t2 = -3 * q / (2 * p);

                double x1 = t1 - b / 3;
                double x2 = t2 - b / 3;

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n🎯 === SOLUTIONS === 🎯");
                Console.WriteLine($"x1 = {x1} (racine simple)");
                Console.WriteLine($"x2 = {x2} (racine double)");
                Console.ResetColor();
            }
            else
            {
                Console.WriteLine("Discriminant < 0: On entre dans le monde des nombres imaginaires! 🌈");

                double u = Math.Cbrt(-q / 2 + Math.Sqrt(-discriminant / 108));
                double v = Math.Cbrt(-q / 2 - Math.Sqrt(-discriminant / 108));

                double x1 = u + v - b / 3;

                double partiereelle = -(u + v) / 2 - b / 3;
                double partieimaginaire = (u - v) * Math.Sqrt(3) / 2;

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n✨ === SOLUTIONS === ✨");
                Console.WriteLine($"x1 = {x1} (la seule reelle du groupe)");
                Console.WriteLine($"x2 = {partiereelle} + {partieimaginaire}i");
                Console.WriteLine($"x3 = {partiereelle} - {partieimaginaire}i");
                Console.ResetColor();
            }
            Console.ResetColor();
        }

        static void MethodeCardan(double a, double b, double c, double d)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n--- ETAPE 1: Normalisation a la Cardan ---");

            double B = b / a;
            double C = c / a;
            double D = d / a;
            Console.WriteLine($"x³ + ({B})x² + ({C})x + ({D}) = 0");

            Console.WriteLine("\n--- ETAPE 2: Le changement de variable magique ---");
            Console.WriteLine($"x = t - {B / 3}");

            double p = C - (B * B) / 3;
            double q = (2 * B * B * B) / 27 - (B * C) / 3 + D;

            Console.WriteLine($"\nEquation reduite: t³ + pt + q = 0");
            Console.WriteLine($"p = {p}");
            Console.WriteLine($"q = {q}");

            Console.WriteLine("\n--- ETAPE 3: Le discriminant de Cardan ---");

            double delta = -(4 * p * p * p + 27 * q * q);
            Console.WriteLine($"Δ = {delta}");

            Console.WriteLine("\n--- ETAPE 4: La grande finale de Cardan ---");

            if (Math.Abs(delta) < 1e-10)
            {
                Console.WriteLine("Δ = 0 : C'est un cas special!");

                double t1 = (3 * q) / p;
                double t2 = -(3 * q) / (2 * p);

                double x1 = t1 - B / 3;
                double x2 = t2 - B / 3;

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n🏆 === SOLUTIONS === 🏆");
                Console.WriteLine($"x1 = {x1}");
                Console.WriteLine($"x2 = x3 = {x2} (racine double!)");
                Console.ResetColor();
            }
            else if (delta > 0)
            {
                Console.WriteLine("Δ > 0 : Le cas trigonometrique!");

                double r = 2 * Math.Sqrt(-p / 3);
                double theta = Math.Acos((3 * q) / (p * r)) / 3;

                double t1 = r * Math.Cos(theta);
                double t2 = r * Math.Cos(theta - (2 * Math.PI / 3));
                double t3 = r * Math.Cos(theta - (4 * Math.PI / 3));

                double x1 = t1 - B / 3;
                double x2 = t2 - B / 3;
                double x3 = t3 - B / 3;

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n🎊 === SOLUTIONS === 🎊");
                Console.WriteLine($"x1 = {x1}");
                Console.WriteLine($"x2 = {x2}");
                Console.WriteLine($"x3 = {x3}");
                Console.ResetColor();
            }
            else
            {
                Console.WriteLine("Δ < 0 : Le cas classique de Cardan!");

                double discriminantRacine = Math.Sqrt(-delta / 108);
                double u = Math.Cbrt(-q / 2 + discriminantRacine);
                double v = Math.Cbrt(-q / 2 - discriminantRacine);

                double t1 = u + v;
                double x1 = t1 - B / 3;

                double partieReelle = -(u + v) / 2 - B / 3;
                double partieImaginaire = Math.Abs((u - v) * Math.Sqrt(3) / 2);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n🌟 === SOLUTIONS === 🌟");
                Console.ResetColor();
                Console.ForegroundColor= ConsoleColor.DarkYellow;
                Console.WriteLine($"x1 = {x1} (la racine reelle solitaire)");
                Console.WriteLine($"x2 = {partieReelle} + {partieImaginaire}i");
                Console.WriteLine($"x3 = {partieReelle} - {partieImaginaire}i");
                Console.ResetColor();
            }
        }

        static double LireCoefficient(string nom)
        {
            while (true)
            {
                Console.Write($"Entrez le coefficient {nom}: ");
                string input = Console.ReadLine();

                if (ContientLettres(input))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("ERREUR: Les lettres ne sont pas autorisees!");
                    Console.ResetColor();
                    continue;
                }

                if (double.TryParse(input, out double resultat))
                {
                    return resultat;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("ERREUR: Valeur invalide!");
                    Console.ResetColor();
                }
            }
        }

        static bool ContientLettres(string texte)
        {
            foreach (char c in texte)
            {
                if (char.IsLetter(c))
                {
                    return true;
                }
            }
            return false;
        }
    }
}